﻿using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace POKFKA
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var context = new AppDbContext())
            {

                context.Database.EnsureCreated();

                Console.WriteLine("=== SISTEMA KFKA COM BANCO DE DADOS ===\n");

                if (!context.Alunos.Any())
                {
                    Aluno aluno1 = new Aluno("Ana Beatriz", "ana@escola.com", "26028945");
                    Aluno aluno2 = new Aluno("Carlos Eduardo", "carlos@escola.com", "26028946");

                    Professor prof1 = new Professor("Renata Tanana", "renata@escola.com", "Matemática");
                    Professor prof2 = new Professor("João Silva", "joao@escola.com", "Português");

                    AcomBimestral relatorio1 = new AcomBimestral(
                        aluno1, prof1, 1, 8.5m, "Excelente desempenho e participação ativa nas aulas."
                    );

                    AcomBimestral relatorio2 = new AcomBimestral(
                        aluno2, prof2, 1, 6.7m, "Bom desempenho e participação nas aulas."
                    );

                    context.Alunos.Add(aluno1);
                    context.Alunos.Add(aluno2);
                    context.Professores.Add(prof1);
                    context.Professores.Add(prof2);
                    context.AcompanhamentosBimestrais.Add(relatorio1);
                    context.AcompanhamentosBimestrais.Add(relatorio2);

                    context.SaveChanges();
                    Console.WriteLine("Dados gravados com sucesso no banco de dados!\n");
                }

                var relatorios = context.AcompanhamentosBimestrais
                    .Include(r => r.Aluno)
                    .Include(r => r.Professor)
                    .ToList();

                foreach (var relatorio in relatorios)
                {
                    relatorio.ExibirRelatorio();
                }
            }

            Console.WriteLine("Pressione qualquer tecla para sair...");
            Console.ReadKey();
        }
    }
}