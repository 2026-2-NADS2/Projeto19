﻿namespace POKFKA
{
    public class Pessoa
    {
        public int Id { get; set; } // <--- Chave primária para o Entity Framework Core
        public string Nome { get; set; }
        public string Email { get; set; }

        // Construtor vazio necessário para o EF Core
        public Pessoa() { }

        public Pessoa(string nome, string email)
        {
            Nome = nome;
            Email = email;
        }
    }

    public class Aluno : Pessoa
    {
        public string Matricula { get; set; }

        // Construtor vazio necessário para o EF Core
        public Aluno() : base() { }

        public Aluno(string nome, string email, string matricula) : base(nome, email)
        {
            Matricula = matricula;
        }

        public void ExibirAluno()
        {
            System.Console.WriteLine($"[Aluno] Nome: {Nome} | E-mail: {Email} | Matrícula: {Matricula}");
        }
    }
}