﻿using System;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;

namespace PaginacaoAlunos
{
    class Program
    {
        private static string connectionString = "Data Source=escola.db";

        static void Main(string[] args)
        {
            InicializarBancoDeDados();

            int tamanhoPagina = 3;
            int paginaAtual = 1;
            string opcao = "";

            while (opcao != "S")
            {
                int totalAlunos = ObterTotalAlunos();
                int totalPaginas = (totalAlunos + tamanhoPagina - 1) / tamanhoPagina;
                if (totalPaginas == 0) totalPaginas = 1;

                if (paginaAtual > totalPaginas) paginaAtual = totalPaginas;
                if (paginaAtual < 1) paginaAtual = 1;

                Console.Clear();
                Console.WriteLine("=== SISTEMA DE PAGINAÇÃO DE ALUNOS ===");
                Console.WriteLine($"Total de Alunos: {totalAlunos} | Página {paginaAtual} de {totalPaginas}\n");

                List<Aluno> alunosNaPagina = ObterAlunosPorPagina(paginaAtual, tamanhoPagina);

                Console.WriteLine($"{"RA",-12} | {"Nome",-16} | {"Nota",5}");
                Console.WriteLine(new string('-', 40));

                foreach (var aluno in alunosNaPagina)
                {
                    Console.WriteLine($"{aluno.RA,-12} | {aluno.Nome,-16} | {aluno.Nota,5:F1}");
                }

                Console.WriteLine(new string('-', 40));
                Console.WriteLine("\nControles: [X] Próxima | [Z] Anterior | [S] Sair");
                Console.Write("Digite a opção: ");

                var input = Console.ReadLine();
                opcao = input != null ? input.ToUpper() : "";

                if (opcao == "X" && paginaAtual < totalPaginas)
                {
                    paginaAtual++;
                }
                else if (opcao == "Z" && paginaAtual > 1)
                {
                    paginaAtual--;
                }
            }

            Console.WriteLine("\nPrograma encerrado.");
        }

        private static void InicializarBancoDeDados()
        {
            using (var conexao = new SqliteConnection(connectionString))
            {
                conexao.Open();

                string sqlDrop = "DROP TABLE IF EXISTS Alunos;";
                using (var cmdDrop = new SqliteCommand(sqlDrop, conexao))
                {
                    cmdDrop.ExecuteNonQuery();
                }

                string sqlTabela = @"
            CREATE TABLE IF NOT EXISTS Alunos (
                RA INTEGER PRIMARY KEY,
                Nome TEXT NOT NULL,
                Nota REAL NOT NULL
            );";

                using (var cmd = new SqliteCommand(sqlTabela, conexao))
                {
                    cmd.ExecuteNonQuery();
                }

                string sqlInsert = @"
            INSERT INTO Alunos (RA, Nome, Nota) VALUES 
            (26021110, 'João Silva', 6.6),
            (26021111, 'Maria Souza', 5.0),
            (26021112, 'José Santos', 3.0),
            (26021113, 'Ana Oliveira', 9.1),
            (26021114, 'Bia Lima', 8.3),
            (26021115, 'Carlos Eduardo', 7.0),
            (26021116, 'Fernanda Costa', 4.5),
            (26021117, 'Lucas Rocha', 9.0);
        ";
                using (var cmdInsert = new SqliteCommand(sqlInsert, conexao))
                {
                    cmdInsert.ExecuteNonQuery();
                }
            }
        }

        private static int ObterTotalAlunos()
        {
            using (var conexao = new SqliteConnection(connectionString))
            {
                conexao.Open();
                string sql = "SELECT COUNT(*) FROM Alunos;";
                using (var cmd = new SqliteCommand(sql, conexao))
                {
                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        private static List<Aluno> ObterAlunosPorPagina(int pagina, int tamanhoPagina)
        {
            var lista = new List<Aluno>();
            int offset = (pagina - 1) * tamanhoPagina;

            using (var conexao = new SqliteConnection(connectionString))
            {
                conexao.Open();
                string sql = "SELECT RA, Nome, Nota FROM Alunos LIMIT @limit OFFSET @offset;";

                using (var cmd = new SqliteCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@limit", tamanhoPagina);
                    cmd.Parameters.AddWithValue("@offset", offset);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            lista.Add(new Aluno
                            {
                                RA = reader.GetInt32(0),
                                Nome = reader.GetString(1),
                                Nota = reader.GetDouble(2)
                            });
                        }
                    }
                }
            }
            return lista;
        }
    }
}