﻿namespace POKFKA
{
    public class Professor : Pessoa
    {
        public string Disciplina { get; set; }

        public Professor(string nome, string email, string disciplina) : base(nome, email)
        {
            Disciplina = disciplina;
        }

        public void ExibirProfessor()
        {
            Console.WriteLine($"[Professor] Nome: {Nome} | E-mail: {Email} | Disciplina: {Disciplina}");
        }
    }
}