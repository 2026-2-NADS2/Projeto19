﻿namespace PaginacaoAlunos
{
    public class Aluno
    {
        public int RA { get; set; }
        public string Nome { get; set; }
        public double Nota { get; set; }
    }
}