﻿using Microsoft.EntityFrameworkCore;

namespace POKFKA
{
    public class AppDbContext : DbContext
    {
        public DbSet<Aluno> Alunos { get; set; }
        public DbSet<Professor> Professores { get; set; }
        public DbSet<AcomBimestral> AcompanhamentosBimestrais { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=sistema.db");
        }
    }
}