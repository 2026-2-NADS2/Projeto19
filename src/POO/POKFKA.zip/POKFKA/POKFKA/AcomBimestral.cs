﻿namespace POKFKA
{
    public class AcomBimestral
    {
        public int Id { get; set; }

        public int AlunoId { get; set; }
        public Aluno Aluno { get; set; }

        public int ProfessorId { get; set; }
        public Professor Professor { get; set; }

        public int Bimestre { get; set; }
        public decimal Media { get; set; }
        public string Parecer { get; set; }

        // Construtor vazio necessário para o Entity Framework Core / SQLite
        public AcomBimestral() { }

        // Construtor com parâmetros para uso no código
        public AcomBimestral(Aluno aluno, Professor professor, int bimestre, decimal media, string parecer)
        {
            Aluno = aluno;
            Professor = professor;
            Bimestre = bimestre;
            Media = media;
            Parecer = parecer;
        }

        public void ExibirRelatorio()
        {
            Console.WriteLine($"--- Acompanhamento Bimestral ---");
            Console.WriteLine($"Bimestre: {Bimestre}º");
            Console.WriteLine($"Média: {Media}");
            Console.WriteLine($"Parecer: {Parecer}");
            if (Aluno != null) System.Console.WriteLine($"Aluno: {Aluno.Nome}");
            if (Professor != null) System.Console.WriteLine($"Professor: {Professor.Nome} ({Professor.Disciplina})");
            Console.WriteLine("---------------------------------\n");
        }
    }
}